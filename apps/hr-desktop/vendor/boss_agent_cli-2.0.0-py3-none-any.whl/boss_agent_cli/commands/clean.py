"""boss clean — 清理过期缓存和临时文件。"""

from __future__ import annotations

import shutil
import sqlite3
import time
from pathlib import Path
from typing import Any

import click

from rich.table import Table

from boss_agent_cli import display
from boss_agent_cli.display import handle_output, render_next_steps


@click.command("clean")
@click.option("--dry-run", is_flag=True, default=False, help="仅预览将清理的内容，不实际删除")
@click.option("--all", "clean_all", is_flag=True, default=False, help="清理全部缓存（包括未过期的搜索缓存和打招呼记录）")
@click.option("--privacy", is_flag=True, default=False, help="清理本地敏感数据（登录会话、简历、聊天快照和导出文件）")
@click.option("--days", default=30, help="清理超过指定天数的快照和导出文件")
@click.pass_context
def clean_cmd(ctx: click.Context, dry_run: bool, clean_all: bool, privacy: bool, days: int) -> None:
	"""清理过期缓存和临时文件。"""
	data_dir = ctx.obj["data_dir"]
	results = []
	total_freed = 0

	# 1) 搜索缓存
	freed, count = _clean_search_cache(data_dir, dry_run=dry_run, clean_all=clean_all)
	results.append({"target": "搜索缓存", "cleaned": count, "bytes_freed": freed})
	total_freed += freed

	# 2) 索引缓存
	freed, count = _clean_index_cache(data_dir, dry_run=dry_run)
	results.append({"target": "索引缓存", "cleaned": count, "bytes_freed": freed})
	total_freed += freed

	# 3) 聊天快照
	freed, count = _clean_dir(data_dir / "chat-history", days=days, dry_run=dry_run)
	results.append({"target": "聊天快照", "cleaned": count, "bytes_freed": freed})
	total_freed += freed

	# 4) 导出文件
	freed, count = _clean_dir(data_dir / "chat-export", days=days, dry_run=dry_run)
	results.append({"target": "导出文件", "cleaned": count, "bytes_freed": freed})
	total_freed += freed

	# 5) 隐私清理：显式 opt-in，避免误删登录态和本地简历
	if privacy:
		for target, path in (
			("登录会话", data_dir / "auth" / "session.enc"),
			("本地简历", data_dir / "resumes"),
			("聊天快照", data_dir / "chat-history"),
			("导出文件", data_dir / "chat-export"),
		):
			freed, count = _clean_path(path, dry_run=dry_run)
			results.append({"target": target, "cleaned": count, "bytes_freed": freed})
			total_freed += freed
		freed, count = _clean_crawl_data(data_dir, dry_run=dry_run)
		results.append({"target": "crawl 任务与导出", "cleaned": count, "bytes_freed": freed})
		total_freed += freed

	# 6) 全量清理额外项
	if clean_all:
		freed, count = _clean_greet_records(data_dir, dry_run=dry_run)
		results.append({"target": "打招呼记录", "cleaned": count, "bytes_freed": freed})
		total_freed += freed

		freed, count = _clean_apply_records(data_dir, dry_run=dry_run)
		results.append({"target": "投递记录", "cleaned": count, "bytes_freed": freed})
		total_freed += freed

	data = {
		"dry_run": dry_run,
		"results": results,
		"total_bytes_freed": total_freed,
		"total_bytes_freed_display": _format_size(total_freed),
	}

	hints: dict[str, list[str]] = {"next_actions": []}
	if dry_run:
		hints["next_actions"].append("boss clean — 执行实际清理")
	elif privacy:
		hints["next_actions"].append("boss login — 隐私清理后需要重新登录")
		hints["next_actions"].append("boss doctor — 检查清理后环境状态")
	else:
		hints["next_actions"].append("boss doctor — 检查清理后环境状态")

	handle_output(
		ctx,
		"clean",
		data,
		render=lambda d: _render_clean(d, hints["next_actions"]),
		hints=hints,
	)


def _render_clean(data: dict[str, Any], next_steps: list[str]) -> None:
	"""清理结果表格（TTY 路径）。dry-run 时明确标注未真正删除。"""
	title = "clean（预演，未实际删除）" if data.get("dry_run") else "clean"
	table = Table(title=title)
	table.add_column("目标", style="bold cyan")
	table.add_column("条数", justify="right", style="green")
	table.add_column("释放", justify="right", style="yellow")
	for row in data.get("results", []):
		table.add_row(
			str(row.get("target", "-")),
			str(row.get("cleaned", 0)),
			_human_bytes(row.get("bytes_freed", 0)),
		)
	display.console.print(table)
	display.console.print(f"  合计释放 [bold]{data.get('total_bytes_freed_display', '0 B')}[/bold]")
	render_next_steps(next_steps)


def _human_bytes(value: int) -> str:
	"""字节数转人类可读；与信封里的 total_bytes_freed_display 口径一致。"""
	size = float(value)
	for unit in ("B", "KB", "MB", "GB"):
		if size < 1024 or unit == "GB":
			return f"{int(size)} {unit}" if unit == "B" else f"{size:.1f} {unit}"
		size /= 1024
	return f"{size:.1f} GB"


def _clean_search_cache(data_dir: Path, *, dry_run: bool, clean_all: bool) -> tuple[int, int]:
	"""清理搜索缓存，返回 (释放字节数, 清理条数)。"""
	db_path = data_dir / "cache" / "boss_agent.db"
	if not db_path.exists():
		return 0, 0

	conn = sqlite3.connect(str(db_path))
	try:
		if clean_all:
			row = conn.execute("SELECT COUNT(*), COALESCE(SUM(LENGTH(response)), 0) FROM search_cache").fetchone()
		else:
			cutoff = time.time() - 86400
			row = conn.execute(
				"SELECT COUNT(*), COALESCE(SUM(LENGTH(response)), 0) FROM search_cache WHERE created_at < ?",
				(cutoff,),
			).fetchone()

		count, size = row[0], row[1]
		if not dry_run and count > 0:
			if clean_all:
				conn.execute("DELETE FROM search_cache")
			else:
				conn.execute("DELETE FROM search_cache WHERE created_at < ?", (cutoff,))
			conn.commit()
			conn.execute("VACUUM")
		return size, count
	finally:
		conn.close()


def _clean_index_cache(data_dir: Path, *, dry_run: bool) -> tuple[int, int]:
	"""清理索引缓存文件。"""
	path = data_dir / "cache" / "index_cache.json"
	if not path.exists():
		return 0, 0
	size = path.stat().st_size
	if not dry_run:
		path.unlink()
	return size, 1


def _clean_dir(dir_path: Path, *, days: int, dry_run: bool) -> tuple[int, int]:
	"""清理指定目录中超过指定天数的文件。"""
	if not dir_path.exists():
		return 0, 0

	cutoff = time.time() - days * 86400
	total_size = 0
	count = 0

	for f in dir_path.iterdir():
		if f.is_file() and f.stat().st_mtime < cutoff:
			total_size += f.stat().st_size
			count += 1
			if not dry_run:
				f.unlink()

	return total_size, count


def _clean_path(path: Path, *, dry_run: bool) -> tuple[int, int]:
	"""清理单个文件或目录，返回 (释放字节数, 清理条数)。"""
	if not path.exists():
		return 0, 0
	size, count = _path_stats(path)
	if not dry_run:
		if path.is_dir():
			shutil.rmtree(path)
		else:
			path.unlink()
	return size, count


def _path_stats(path: Path) -> tuple[int, int]:
	"""统计文件/目录字节数和文件数量。"""
	if path.is_file():
		return path.stat().st_size, 1
	if not path.is_dir():
		return 0, 0
	size = 0
	count = 0
	for item in path.rglob("*"):
		if item.is_file():
			size += item.stat().st_size
			count += 1
	return size, count


def _clean_greet_records(data_dir: Path, *, dry_run: bool) -> tuple[int, int]:
	"""清理打招呼记录。"""
	return _clean_table(data_dir, "greet_records", dry_run=dry_run)


def _clean_apply_records(data_dir: Path, *, dry_run: bool) -> tuple[int, int]:
	"""清理投递记录。"""
	return _clean_table(data_dir, "apply_records", dry_run=dry_run)


def _clean_crawl_data(data_dir: Path, *, dry_run: bool) -> tuple[int, int]:
	files_size, files_count = _clean_path(data_dir / "crawl", dry_run=dry_run)
	db_path = data_dir / "cache" / "boss_agent.db"
	if not db_path.exists():
		return files_size, files_count
	conn = sqlite3.connect(str(db_path))
	try:
		row = conn.execute("SELECT COUNT(*) FROM crawl_runs").fetchone()
		count = int(row[0])
		if not dry_run:
			conn.execute("DELETE FROM crawl_jobs")
			conn.execute("DELETE FROM crawl_runs")
			conn.execute("DELETE FROM crawl_budget")
			conn.commit()
		return files_size + count * 200, files_count + count
	finally:
		conn.close()


def _clean_table(data_dir: Path, table: str, *, dry_run: bool) -> tuple[int, int]:
	"""清理数据库表，返回 (估算字节数, 行数)。"""
	db_path = data_dir / "cache" / "boss_agent.db"
	if not db_path.exists():
		return 0, 0

	conn = sqlite3.connect(str(db_path))
	try:
		row = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()  # noqa: S608
		count = row[0]
		estimated_size = count * 100
		if not dry_run and count > 0:
			conn.execute(f"DELETE FROM {table}")  # noqa: S608
			conn.commit()
		return estimated_size, count
	finally:
		conn.close()


def _format_size(size_bytes: int) -> str:
	"""格式化字节数为可读字符串。"""
	if size_bytes < 1024:
		return f"{size_bytes} B"
	elif size_bytes < 1024 * 1024:
		return f"{size_bytes / 1024:.1f} KB"
	else:
		return f"{size_bytes / (1024 * 1024):.1f} MB"
