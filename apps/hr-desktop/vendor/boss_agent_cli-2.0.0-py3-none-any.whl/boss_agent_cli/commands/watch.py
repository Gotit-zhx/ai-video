import click
from typing import Any

from boss_agent_cli.api.endpoints import (
	CITY_CODES,
	INDUSTRY_CODES,
	JOB_TYPE_CODES,
	SCALE_CODES,
	STAGE_CODES,
)
from boss_agent_cli.auth.manager import AuthManager
from boss_agent_cli.cache.store import CacheStore
from boss_agent_cli.compliance import require_compliance_allowed
from boss_agent_cli.commands._platform import get_platform_instance
from boss_agent_cli.display import (
	handle_auth_errors,
	handle_error_output,
	handle_output,
	render_action_result,
	render_list_result,
	render_message_panel,
)
from boss_agent_cli.search_filters import SearchFilterCriteria, SearchPipelinePlatformError, build_search_params, resolve_welfare_keywords, run_search_pipeline


def _parse_watch_filters(
	query: str,
	city: str | None,
	salary: str | None,
	experience: str | None,
	education: str | None,
	industry: str | None,
	scale: str | None,
	stage: str | None,
	job_type: str | None,
	welfare: str | None,
) -> tuple[dict[str, str | None], list[tuple[str, list[str]]] | None]:
	params = build_search_params(query, city, salary, experience, education, industry, scale, stage, job_type, welfare)
	welfare_conditions = None
	if welfare:
		labels = [w.strip() for w in welfare.split(",") if w.strip()]
		welfare_conditions = [(label, resolve_welfare_keywords(label)) for label in labels]
	return params, welfare_conditions


@click.group("watch")
def watch_group() -> None:
	"""保存搜索条件并执行增量监控。"""


@watch_group.command("add")
@click.argument("name")
@click.argument("query")
@click.option("--city", default=None, help="城市名称")
@click.option("--salary", default=None, help="薪资范围")
@click.option("--experience", default=None, help="经验要求")
@click.option("--education", default=None, help="学历要求")
@click.option("--industry", default=None, type=click.Choice(list(INDUSTRY_CODES.keys()), case_sensitive=False), help="行业类型")
@click.option("--scale", default=None, type=click.Choice(list(SCALE_CODES.keys()), case_sensitive=False), help="公司规模")
@click.option("--stage", default=None, type=click.Choice(list(STAGE_CODES.keys()), case_sensitive=False), help="融资阶段")
@click.option("--job-type", default=None, type=click.Choice(list(JOB_TYPE_CODES.keys()), case_sensitive=False), help="职位类型")
@click.option("--welfare", default=None, help="福利筛选")
@click.pass_context
def watch_add_cmd(
	ctx: click.Context,
	name: str,
	query: str,
	city: str | None,
	salary: str | None,
	experience: str | None,
	education: str | None,
	industry: str | None,
	scale: str | None,
	stage: str | None,
	job_type: str | None,
	welfare: str | None,
) -> None:
	if city and city not in CITY_CODES:
		handle_error_output(ctx, "watch", code="INVALID_PARAM", message=f"未知城市: {city}")
		return

	params, _ = _parse_watch_filters(query, city, salary, experience, education, industry, scale, stage, job_type, welfare)
	with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
		cache.save_saved_search(name, params)
	handle_output(
		ctx, "watch",
		{"action": "add", "name": name, "params": params},
		render=lambda d: render_action_result(
			d, title="watch", next_steps=[f"boss watch run {name}", "boss watch list"]
		),
		hints={"next_actions": [f"boss watch run {name}", "boss watch list"]},
	)


@watch_group.command("list")
@click.pass_context
def watch_list_cmd(ctx: click.Context) -> None:
	with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
		items = cache.list_saved_searches()
	handle_output(
		ctx,
		"watch",
		items,
		render=lambda d: render_list_result(
			d,
			"watches",
			[("名称", "name", "bold cyan"), ("条件", "params", "green"), ("创建时间", "created_at", "dim")],
			next_steps=["boss watch add <name> --query <关键词>"]
			if not d
			else ["boss watch run <name>", "boss watch remove <name>"],
		),
		hints={"next_actions": ["boss watch run <name>", "boss watch remove <name>"]},
	)


@watch_group.command("remove")
@click.argument("name")
@click.pass_context
def watch_remove_cmd(ctx: click.Context, name: str) -> None:
	with CacheStore(ctx.obj["data_dir"] / "cache" / "boss_agent.db") as cache:
		removed = cache.delete_saved_search(name)
	handle_output(
		ctx,
		"watch",
		{"action": "remove", "name": name, "removed": removed},
		render=lambda d: render_action_result(d, title="watch", next_steps=["boss watch list"]),
	)


def _execute_single_watch(ctx: click.Context, cache: Any, name: str) -> dict[str, Any] | None:
	"""执行单个 watch，返回聚合结果；找不到时返回 None。"""
	record = cache.get_saved_search(name)
	if record is None:
		return None

	params = record["params"]
	welfare = params.get("welfare")
	_, welfare_conditions = _parse_watch_filters(
		params.get("query"),
		params.get("city"),
		params.get("salary"),
		params.get("experience"),
		params.get("education"),
		params.get("industry"),
		params.get("scale"),
		params.get("stage"),
		params.get("job_type"),
		welfare,
	)
	criteria = SearchFilterCriteria(
		query=params.get("query", ""),
		city=params.get("city"),
		salary=params.get("salary"),
		experience=params.get("experience"),
		education=params.get("education"),
		industry=params.get("industry"),
		scale=params.get("scale"),
		stage=params.get("stage"),
		job_type=params.get("job_type"),
	)
	data_dir = ctx.obj["data_dir"]
	logger = ctx.obj["logger"]
	auth = AuthManager(data_dir, logger=logger, platform=ctx.obj.get("platform", "zhipin"))
	with get_platform_instance(ctx, auth) as platform:
		pipeline_result = run_search_pipeline(
			platform,
			cache,
			logger,
			criteria=criteria,
			start_page=1,
			max_pages=5 if welfare_conditions else 1,
			welfare_conditions=welfare_conditions,
		)
	watch_result = cache.record_watch_results(name, pipeline_result.items)
	return {
		"name": name,
		"new_count": watch_result["new_count"],
		"seen_count": watch_result["seen_count"],
		"total_count": watch_result["total_count"],
		"new_items": watch_result["new_items"],
	}


@watch_group.command("run")
@click.argument("name", required=False)
@click.option("--all", "run_all", is_flag=True, help="跑所有已保存 watch")
@click.pass_context
@handle_auth_errors("watch")
def watch_run_cmd(ctx: click.Context, name: str | None, run_all: bool) -> None:
	if not require_compliance_allowed(ctx, "watch-run"):
		ctx.exit(1)

	data_dir = ctx.obj["data_dir"]

	with CacheStore(data_dir / "cache" / "boss_agent.db") as cache:
		if run_all:
			records = cache.list_saved_searches()
			watches: list[dict[str, Any]] = []
			for record in records:
				try:
					summary = _execute_single_watch(ctx, cache, record["name"])
				except SearchPipelinePlatformError as exc:
					summary = {"name": record["name"], "error": exc.code, "message": exc.message}
				if summary is not None:
					watches.append(summary)
			handle_output(
				ctx, "watch",
				{"mode": "all", "watches": watches, "total": len(watches)},
				render=lambda d: render_message_panel(
					{"模式": "全部", "监控数": d.get("total", 0)}, title="watch run"
				),
				hints={"next_actions": ["boss watch list", "boss detail <security_id>"]},
			)
			return

		if not name:
			handle_error_output(
				ctx, "watch",
				code="INVALID_PARAM",
				message="必须传入 watch 名或使用 --all",
				recoverable=False,
			)
			return

		try:
			summary = _execute_single_watch(ctx, cache, name)
		except SearchPipelinePlatformError as exc:
			handle_error_output(
				ctx, "watch",
				code=exc.code,
				message=exc.message or "搜索结果获取失败",
				recoverable=False,
			)
			return

		if summary is None:
			handle_error_output(ctx, "watch", code="JOB_NOT_FOUND", message=f"未找到 watch: {name}")
			return

		handle_output(
			ctx, "watch", summary,
			render=lambda d: render_message_panel(d, title="watch run"),
			hints={"next_actions": ["boss detail <security_id>", "boss watch list"]},
		)
