# 赫逸印花采集 v2.0

解压 ZIP，在 Chrome 扩展程序页面打开开发者模式，选择「加载已解压的扩展程序」，选中 `hoyee-print-collector-v2` 文件夹。Edge 也可通过扩展管理页面加载。v2.0 使用独立的目录和本地登录状态，可与「赫逸商品一键采集」同时安装。

1. 登录 `hoyee.org.cn`，让插件连接同一企业。也可从插件工具栏登录。
2. 刷新 Shopee 或 TikTok Shop 商品详情页，点击「采集印花图 v2.0」。遇到平台验证时，完成验证后再采集。
3. 插件打开「商品运营 v2.0 → 采集链接」。选一张商品图，确认提取印花，再选择采集模板套版。提取印花会调用图片模型，费用按平台配置计。

插件仅向赫逸平台提交当前商品的链接、标题及最多 20 张图片地址。商品图保存在独立的印花来源命名空间，原商品采集列表、SKU、视频和发布流程沿用既有版本。

从项目根目录打包：

```sh
python3 apps/browser-extension-v2/scripts/package.py --output ./hoyee-print-collector-v2.zip
```

v2.0 复用同仓库的 Shopee、TikTok Shop 和登录适配器。打包脚本检查 Manifest 引用和所有 ZIP 条目。
